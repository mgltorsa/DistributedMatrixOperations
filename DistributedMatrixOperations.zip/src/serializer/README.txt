frascati compile src/main/java serializer
frascati run src/main/resources/serializer -libpath serializer.jar -s r -m run
