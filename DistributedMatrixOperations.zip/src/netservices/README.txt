frascati compile src/main/java broker
frascati run src/main/resources/broker -libpath broker.jar
