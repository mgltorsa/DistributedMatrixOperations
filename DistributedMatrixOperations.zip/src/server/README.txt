frascati compile src/main/java server
frascati run src/main/resources/server -libpath server.jar
