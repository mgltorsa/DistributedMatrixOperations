frascati compile src/main/java client
frascati run src/main/resources/client -libpath client.jar -s rotate -m run
